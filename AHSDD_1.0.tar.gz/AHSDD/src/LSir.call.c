#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#define R2pi sqrt(2*3.141593)

SEXP LSirC(
SEXP offsprings, SEXP parents, SEXP max_offsprings, SEXP max_parents, SEXP n_draws,
SEXP beta2_min, SEXP beta2_max,
SEXP sd_log_min, SEXP sd_log_max){
	
	/*D�clarations */
	
	// coerce data class
	offsprings = coerceVector(offsprings,INTSXP);
	parents = coerceVector(parents,INTSXP);
	max_offsprings = coerceVector(max_offsprings,INTSXP);
	max_parents = coerceVector(max_parents,INTSXP);
	n_draws = coerceVector(n_draws,INTSXP);
	beta2_min = coerceVector(beta2_min,REALSXP); beta2_max = coerceVector(beta2_max,REALSXP);
	sd_log_min = coerceVector(sd_log_min,REALSXP); sd_log_max = coerceVector(sd_log_max,REALSXP);
	
	// define model parameters
	int n_data;	n_data = length(offsprings);
	int counter, i;
	long int n_models_tried;
	double L, best_L, cum_L, sum_L_n_models_tried, sum_ll;
	double beta2, sd_log;
	double Den1, Den2, Num1, Num2, Expo;
	double pred[n_data];
	
	// define outputs
	double *intermediate;
	SEXP l_outputs ;
	PROTECT(l_outputs = allocVector(REALSXP, INTEGER(n_draws)[0] * 5));
	intermediate = REAL(l_outputs);
	
	/*Initialisation */
	counter = 0;
	n_models_tried = 0;
	sum_ll = 0.;
	best_L = 0.;
	cum_L = 0.;
	sum_L_n_models_tried = 0.;
	
	while (counter<INTEGER(n_draws)[0]){       
		
		// sampling parameters values in priors
		GetRNGstate();
		beta2= runif(REAL(beta2_min)[0], REAL(beta2_max)[0]);
		PutRNGstate();
		GetRNGstate();
		sd_log= runif(REAL(sd_log_min)[0], REAL(sd_log_max)[0]);
		PutRNGstate();  
		
		// calculus of related parameters, empty for this model
		
		// updating some values used in the SIR function or latter on when assessing model weights  
		n_models_tried++;
		sum_ll= 0.; 
		
		// loop for log likelyhood calculus
		for(i= 0; i < n_data; i++){
			pred[i]= beta2 * INTEGER(parents)[i];
			Den1= INTEGER(offsprings)[i] * R2pi * sd_log;
			Num1= log(INTEGER(offsprings)[i])- log(pred[i]);
			Num1+= 0.5 * pow(sd_log, 2);
			Num2= pow(Num1, 2);
			Den2= pow(sd_log, 2);
			Den2*= 2.;
			Expo= Num2 / Den2;
			Expo*= -1.;
			sum_ll+=log((1. / Den1) * exp(Expo));
		}// end for loop
		
		// update of likelyhood related variables used in the SIR function
		L = expl(sum_ll);
		sum_L_n_models_tried = sum_L_n_models_tried + L;
		n_models_tried++;
		
		// restart the SIR loop if current likelyhood better than the reference barr chosen (= best.ll)
		if(L>best_L){
			best_L= 1.10 * L;
			counter= 0;
			cum_L= 0.;
		}// end if statement
		
		// continue SIR process if previous if loop not satisfied   
		cum_L= cum_L + L;
		
		// what to do if reference barr passed
		if(cum_L > best_L){
			
			// recording of the value of parameters and likelyhood related variables
			intermediate[INTEGER(n_draws)[0] * 0 + counter]= beta2;
			intermediate[INTEGER(n_draws)[0] * 1 + counter]= sd_log;
			intermediate[INTEGER(n_draws)[0] * 2 + counter]= sum_ll;
			intermediate[INTEGER(n_draws)[0] * 3 + counter]= n_models_tried;
			intermediate[INTEGER(n_draws)[0] * 4 + counter]= sum_L_n_models_tried;
			
			//update counter and likelyhood related parameters
			counter++;
			cum_L-= best_L; 
			
		}// end if statement
		
	}// end while loop
	
	UNPROTECT(1);
	return l_outputs;
	
}// end C funtion  
