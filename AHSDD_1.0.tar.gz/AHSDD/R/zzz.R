#.First.lib <- function (lib, pkg){
#  library.dynam('AHSDD', pkgm lib)
#}

# option when a NAMESPACE file exists
.onLoad <-function (lib, pkg) {
  library.dynam('AHSDD', pkg, lib)
}