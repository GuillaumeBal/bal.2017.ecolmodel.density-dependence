#########################################################################
### complete Allee Hockey Stick Model

AhsSir <- function (
  parents, 
  offsprings, 
  n.draws, 
  beta1.min, beta1.max,
  pd.min, pd.max,
  beta2.min, beta2.max,
  deltap.min, deltap.max,
  sd.log.min, sd.log.max){
  
  # check entry format				
  if(is.integer(parents) * is.integer(offsprings) * is.integer(n.draws) != 1) stop('At least one of the inputs is not of class 
integer')
  
  #check beta1 values
  if(missing(beta1.min)) beta1.min <- 0.01
  if(beta1.min < 0 | beta1.min > 1) stop('beta1.min must lie between 0 and 1')
  if(missing(beta1.max)) beta1.max <- 0.99
  if(beta1.max < 0 | beta1.max > 1) stop('beta1.max must lie between 0 and 1')
  if(beta1.min >= beta1.max) stop('Error, beta1.min must be inferior to beta1.max') 
  
  #check beta2 values
  if(missing(beta2.min)) beta2.min <- 1
  if(beta2.min < 1) stop('beta2.min must be at least equal to 1')
  if(missing(beta2.max)) beta2.max <- 100
  if(beta2.max < 1) stop('beta2.max must be superior to 1')
  if(beta2.min >= beta2.max) stop('Error, beta2.min must be inferior to beta2.max')   
  
  #check pd values
  if(missing(pd.min)) pd.min <- 0.00001
  if(pd.min < 0 | pd.min > 1) stop('Error, pd.min must lie between 0 and 1')
  if(missing(pd.max)) pd.max <- 0.33
  if(pd.max < 0 | pd.max > 1) stop('Error, pd.max must lie between 0 and 1')
  if(pd.min >= pd.max) stop('Error, pd.min must be inferior to pd.max') 
  
  #check deltap values
  if(missing(deltap.min)) deltap.min <- 0.33
  if(deltap.min < 0 | deltap.min > 1) stop('Error, deltap.min must lie between 0 and 1')
  if(missing(deltap.max)) deltap.max <- 0.99
  if(deltap.max < 0 | deltap.max > 1) stop('Error, deltap.max must lie between 0 and 1')
  if(deltap.min >= deltap.max) stop('Error, deltap.min must be inferior to deltap.max')
  
  #check sd.log values
  if(missing(sd.log.min)) sd.log.min <- 0.01
  if(sd.log.min < 0) stop('Error, sd.log.min must be positive')
  if(missing(sd.log.max)) sd.log.max <- 3
  if(sd.log.max < 0) stop('Error, sd.log.max must be positive')
  if(sd.log.min >= sd.log.max) stop('Error, sd.log.min must be inferior to sd.log.max')   
  
  #'rename' variables because C++ soes not support '.' in variable names
  max_offsprings <- max(offsprings)
  max_parents <- max(parents)
  n_draws <- n.draws
  beta1_min <- beta1.min; beta1_max <- beta1.max
  pd_min <- pd.min;	pd_max <- pd.max
  beta2_min <- beta2.min; beta2_max <- beta2.max
  deltap_min <- deltap.min; deltap_max <- deltap.max
  sd_log_min <- sd.log.min; sd_log_max <- sd.log.max
  
  # call C++ functions  
  dens <- matrix(.Call('AhsSirC', 
                       offsprings, 
                       parents, 
                       max_offsprings,
                       max_parents, 
                       n_draws,
                       beta1_min,	beta1_max,
                       pd_min, pd_max,
                       beta2_min, beta2_max,
                       deltap_min,	deltap_max,
                       sd_log_min,	sd_log_max,
                       PACKAGE = 'AHSDD'),
                 ncol = 9,
                 nrow = n.draws, 
                 dimnames = list(
                   NULL,
                   c('beta1', 
                     'pd', 
                     'beta2', 
                     'pc', 
                     'k', 
                     'sd.log', 
                     'll', 
                     'n.models.tried', 
                     'sum.L.n.models.tried')
                 )
  )
}


##############################################################################
### Classical Allee Hockey Stick modele

HsSir <- function (
  parents, 
  offsprings, 
  n.draws,
  beta2.min, beta2.max,
  deltap.min, deltap.max,
  sd.log.min, sd.log.max
){
  
  # check entry format
  if(is.integer(parents) * is.integer(offsprings) * is.integer(n.draws) != 1) stop('At least one of the inputs is not of class 
integer')
  
  #check beta2 values
  if(missing(beta2.min)) beta2.min <- 1
  if(beta2.min < 1) stop('beta2.min must be at least equal to 1')
  if(missing(beta2.max)) beta2.max <- 100
  if(beta2.max < 1) stop('beta2.max must be superior to 1')
  if(beta2.min >= beta2.max) stop('Error, beta2.min must be inferior to beta2.max')   
  
  #check deltap values
  if(missing(deltap.min)) deltap.min <- 0.33
  if(deltap.min < 0 | deltap.min > 1) stop('Error, deltap.min must lie between 0 and 1')
  if(missing(deltap.max)) deltap.max <- 0.99
  if(deltap.max < 0 | deltap.max > 1) stop('Error, deltap.max must lie between 0 and 1')
  if(deltap.min >= deltap.max) stop('Error, deltap.min must be inferior to deltap.max')
  
  #check sd.log values
  if(missing(sd.log.min)) sd.log.min <- 0.01
  if(sd.log.min < 0) stop('Error, sd.log.min must be positive')
  if(missing(sd.log.max)) sd.log.max <- 3
  if(sd.log.max < 0) stop('Error, sd.log.max must be positive')
  if(sd.log.min >= sd.log.max) stop('Error, sd.log.min must be inferior to sd.log.max')   
  
  #'rename' variables because C++ soes not support '.' in variable names
  max_offsprings <- max(offsprings)
  max_parents <- max(parents)
  n_draws <- n.draws
  beta2_min <- beta2.min; beta2_max <- beta2.max
  deltap_min <- deltap.min; deltap_max <- deltap.max
  sd_log_min <- sd.log.min; sd_log_max <- sd.log.max
  
  # call C++ functions 
  dens <- matrix(.Call('HsSirC', 
                       offsprings, 
                       parents, 
                       max_offsprings,
                       max_parents, 
                       n_draws,
                       beta2_min, beta2_max,
                       deltap_min,	deltap_max,
                       sd_log_min,	sd_log_max,
                       PACKAGE = 'AHSDD'),
                 ncol = 7,
                 nrow = n.draws, 
                 dimnames = list(
                   NULL,
                   c('beta2', 
                     'pc', 
                     'k', 
                     'sd.log', 
                     'll', 
                     'n.models.tried', 
                     'sum.L.n.models.tried')
                 )
  )
}

#########################################################################################
### Allee Linear model

AlSir <- function (
  parents, 
  offsprings, 
  n.draws,
  beta1.min, beta1.max,
  pd.min, pd.max,
  beta2.min, beta2.max,
  sd.log.min, sd.log.max){
  
  # check entry format
  if(is.integer(parents) * is.integer(offsprings) * is.integer(n.draws) != 1) stop('At least one of the inputs is not of class 
integer')
  
  #check beta1 values
  if(missing(beta1.min)) beta1.min <- 0.01
  if(beta1.min < 0 | beta1.min > 1 ) stop('beta1.min must lie between 0 and 1')
  if(missing(beta1.max)) beta1.max <- 0.99
  if(beta1.max < 0 | beta1.max > 1) stop('beta1.max must lie between 0 and 1')
  if(beta1.min >= beta1.max) stop('Error, beta1.min must be inferior to beta1.max') 
  
  #check beta2 values
  if(missing(beta2.min)) beta2.min <- 1
  if(beta2.min < 1) stop('beta2.min must be at least equal to 1')
  if(missing(beta2.max)) beta2.max <- 25
  if(beta2.max < 1) stop('beta2.max must be superior to 1')
  if(beta2.min >= beta2.max) stop('Error, beta2.min must be inferior to beta2.max')   
  
  #check pd values
  if(missing(pd.min)) pd.min <- 0.00001
  if(pd.min < 0 | pd.min > 1) stop('Error, pd.min must lie between 0 and 1')
  if(missing(pd.max)) pd.max <- 0.33
  if(pd.max < 0 | pd.max > 1) stop('Error, pd.max must lie between 0 and 1')
  if(pd.min >= pd.max) stop('Error, pd.min must be inferior to pd.max') 
  
  #check sd.log values
  if(missing(sd.log.min)) sd.log.min <- 0.01
  if(sd.log.min < 0) stop('Error, sd.log.min must be positive')
  if(missing(sd.log.max)) sd.log.max <- 3
  if(sd.log.max < 0) stop('Error, sd.log.max must be positive')
  if(sd.log.min >= sd.log.max) stop('Error, sd.log.min must be inferior to sd.log.max')   
  
  #'rename' variables because C++ soes not support '.' in variable names
  max_offsprings <- max(offsprings)
  max_parents <- max(parents)
  n_draws <- n.draws
  beta1_min <- beta1.min; beta1_max <- beta1.max
  pd_min <- pd.min;	pd_max <- pd.max
  beta2_min <- beta2.min; beta2_max <- beta2.max
  sd_log_min <- sd.log.min; sd_log_max <- sd.log.max
  
  #call C++ function
  dens <- matrix(.Call('AlSirC', 
                       offsprings, 
                       parents, 
                       max_offsprings,
                       max_parents, 
                       n_draws,
                       beta1_min,	beta1_max,
                       pd_min, pd_max,
                       beta2_min, beta2_max,
                       sd_log_min,	sd_log_max,
                       PACKAGE = 'AHSDD'),
                 ncol = 7,
                 nrow = n.draws, 
                 dimnames = list(
                   NULL,
                   c('beta1', 
                     'pd', 
                     'beta2', 
                     'sd.log', 
                     'll', 
                     'n.models.tried', 
                     'sum.L.n.models.tried')
                 )
  )
}

#########################################################################################
### Linear model

LSir <- function (
  parents, offsprings, n.draws,
  beta2.min , beta2.max,
  sd.log.min, sd.log.max){
  
  #check beta2 values
  if(missing(beta2.min)) beta2.min <- 1
  if(beta2.min < 1) stop('beta2.min must be at least equal to 1')
  if(missing(beta2.max)) beta2.max <- 25
  if(beta2.max < 1) stop('beta2.max must be superior to 1')
  if(beta2.min >= beta2.max) stop('Error, beta2.min must be inferior to beta2.max') 
  
  #check sd.log values
  if(missing(sd.log.min)) sd.log.min <- 0.01
  if(sd.log.min < 0) stop('Error, sd.log.min must be positive')
  if(missing(sd.log.max)) sd.log.max <- 3
  if(sd.log.max < 0) stop('Error, sd.log.max must be positive')
  if(sd.log.min >= sd.log.max) stop('Error, sd.log.min must be inferior to sd.log.max') 
  
  #'rename' variables because C++ soes not support '.' in variable names
  max_offsprings <- max(offsprings)
  max_parents <- max(parents)
  n_draws <- n.draws
  beta2_min <- beta2.min; beta2_max <- beta2.max
  sd_log_min <- sd.log.min; sd_log_max <- sd.log.max
  
  #call C++ function	
  dens <- matrix(.Call('LSirC', 
                       offsprings, 
                       parents, 
                       max_offsprings,
                       max_parents, 
                       n_draws,
                       beta2_min, beta2_max,
                       sd_log_min, sd_log_max,
                       PACKAGE = 'AHSDD'),
                 ncol = 5,
                 nrow = n.draws, 
                 dimnames = list(
                   NULL,
                   c('beta2', 
                     'sd.log', 
                     'll', 
                     'n.models.tried', 
                     'sum.L.n.models.tried')
                 )
  )
}